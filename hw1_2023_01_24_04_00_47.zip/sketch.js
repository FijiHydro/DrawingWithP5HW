function setup() {
  createCanvas(600, 300);
}

function draw() {
  background(0,220,0);
  ellipse(150,150,250,250);
  rect(325,25,250,250);
}