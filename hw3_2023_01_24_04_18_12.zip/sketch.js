function setup() {
  createCanvas(600, 300);
}

function draw() {
  background(0);
  noStroke();
  
  fill(255,255,0);
  ellipse(150,150,250,250);
  
  fill(0);
  beginShape();
  vertex(0,0);
  vertex(0,300);
  vertex(150,150);
  endShape(CLOSE);
  
  fill(255,0,0);
  ellipse(450,150,250,250);
  rect(325,150,250,125);
  
  fill(255,255,255);
  ellipse(390,150,75,75);
  ellipse(510,150,75,75);
  
  fill(0,0,255);
  ellipse(390,150,50,50);
  ellipse(510,150,50,50);
  
}