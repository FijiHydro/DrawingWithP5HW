function setup() {
  createCanvas(400,400);
}

function draw() {
  noStroke();
  
  fill(255,125,125,75);
  ellipse(200,160,150,150);
  
  fill(125,125,255,75);
  ellipse(150,250,150,150);
  
  fill(125,255,125,75);
  ellipse(250,250,150,150);
}